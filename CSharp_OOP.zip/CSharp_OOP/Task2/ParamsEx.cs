﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThirdPartyLibrary;

namespace Task2
{

    class ParamsEx
    {

        public static void Main_7(string[] args)
        {
            //Example for use of Params parameter
            NamesDisplay("Saddam","Pune");
            NamesDisplay("Javid", "Nadaf", "Natepute", "India", "9766399981");

            Console.Read();

        }

        private static void NamesDisplay(params string[] parameters)
        {
            Console.WriteLine("Employee Details are as follows:");
            
            foreach (var item in parameters)
            {
               Console.WriteLine(item);
            }

        }
    }
}
    //OUTPUT:
    //Employee Details are as follows:
    //Saddam
    //Pune
    //Employee Details are as follows:
    //Javid
    //Nadaf
    //Natepute
    //India
    //9766399981


