﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    public class MultiplicationTable
    {
        static void Main_1(string[] args)
        {

            Console.WriteLine("Displaying Multiplication table for the number accepted by user");
            Console.WriteLine("Enter any Number:");
            int number = Convert.ToInt32(Console.ReadLine());

            for (int i = 1; i <= 20; i++)
            {
                Console.WriteLine("{0} x {1} = {2}", number, i, number * i);
            }

            Console.Read();


        }
    }
}
        // OUTPUT:

        //Displaying Multiplication table for the number accepted by user
        //Enter any Number:
        //19
        //19 x 1 = 19
        //19 x 2 = 38
        //19 x 3 = 57
        //19 x 4 = 76
        //19 x 5 = 95
        //19 x 6 = 114
        //19 x 7 = 133
        //19 x 8 = 152
        //19 x 9 = 171
        //19 x 10 = 190
        //19 x 11 = 209
        //19 x 12 = 228
        //19 x 13 = 247
        //19 x 14 = 266
        //19 x 15 = 285
        //19 x 16 = 304
        //19 x 17 = 323
        //19 x 18 = 342
        //19 x 19 = 361
        //19 x 20 = 380 
