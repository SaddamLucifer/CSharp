﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using ThirdPartyLibrary;

using System;
class sample
{
    public static void IFutureMethod()
    {
        Console.WriteLine("IFutureMethod method");
    }
    public void ZensarMethod(string v)
    {
        first();
        Console.WriteLine("ZensarMethod method");
    }

    public void first()
    {
        
    }

    public void ZensarMethod(int i)
    {
        Console.WriteLine(i);
        ZensarMethod();
    }

    private void ZensarMethod()
    {
        throw new NotImplementedException();
    }
}
class program
{
    public static void Main()
    {
        sample obj = new sample();
        obj.first();
        obj.ZensarMethod("Akkki");
        Console.Read();
    }
}
/*
    Compile Time Errors:
    The name 'first' does not exist in the current context - Line 17
    'sample' does not contain a definition for 'first'     - Line 31
    Argument 1: cannot convert from 'string' to 'int'      - Line 32

    OUTPUT After rectifying errors:
    ZensarMethod method
 */




