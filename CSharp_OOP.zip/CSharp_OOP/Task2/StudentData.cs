﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThirdPartyLibrary;

namespace Task2
{

    class StudentData
    {

        public static void Main_9(string[] args)
        {
            //Example for student data entries
            int[] StudentID = new int[100];
            string[] FullName = new string [100];
            string[] CourseName = new string[100];
            string[] PhoneNo = new string[100];
            int Count = 0;
            Console.WriteLine("Enter how many entries you want to enter:");
            Count = Convert.ToInt32(Console.ReadLine());


                for (int i = 0; i < Count; i++)
                {
                    Console.WriteLine("Enter StudentID:");
                    int ID =   Convert.ToInt32(Console.ReadLine());
                    StudentID[i] = ID;
                    Console.WriteLine("Enter FullName:");
                    string FN = Console.ReadLine();
                    FullName[i] = FN;
                    Console.WriteLine("Enter CourseName:");
                    string CN = Console.ReadLine();
                    CourseName[i] = CN;
                    Console.WriteLine("Enter PhoneNo:");
                    string PN = Console.ReadLine();
                    PhoneNo[i] = PN;
            }

                Console.WriteLine("Students data entered bye user: ");

                for (int i = 0; i < Count; i++)
                {
                    Console.WriteLine("ID: {0}", StudentID[i]);
                    Console.WriteLine("FullName: {0}", FullName[i]);
                    Console.WriteLine("CourseName: {0}", CourseName[i]);
                    Console.WriteLine("PhoneNo: {0}", PhoneNo[i]);

            }

            Console.Read();
        }
    }
}
        /*OUTPUT:
        Enter how many entries you want to enter:
        5
        Enter StudentID:
        1
        Enter FullName:
        javid nadaf
        Enter CourseName:
        csharp
        Enter PhoneNo:
        1236547890
        Enter StudentID:
        2
        Enter FullName:
        tahir nadaf
        Enter CourseName:
        csharp
        Enter PhoneNo:
        7896541230
        Enter StudentID:
        3
        Enter FullName:
        afrin nadaf
        Enter CourseName:
        csharp
        Enter PhoneNo:
        4567891230
        Enter StudentID:
        4
        Enter FullName:
        kajal nadaf
        Enter CourseName:
        csharp
        Enter PhoneNo:
        1239874560
        Enter StudentID:
        5
        Enter FullName:
        samad nadaf
        Enter CourseName:
        csharp
        Enter PhoneNo:
        7458963210
        Students data entered bye user:
        ID: 1
        FullName: javid nadaf
        CourseName: csharp
        PhoneNo: 1236547890
        ID: 2
        FullName: tahir nadaf
        CourseName: csharp
        PhoneNo: 7896541230
        ID: 3
        FullName: afrin nadaf
        CourseName: csharp
        PhoneNo: 4567891230
        ID: 4
        FullName: kajal nadaf
        CourseName: csharp
        PhoneNo: 1239874560
        ID: 5
        FullName: samad nadaf
        CourseName: csharp
        PhoneNo: 7458963210
         */



