﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThirdPartyLibrary;

namespace Task2
{

    class OutputForCode
    {

        public static void Main_6(string[] args)
        {
            //Displaying output for given code 
            Console.WriteLine(Math.Round(12.5));
            Console.WriteLine(Math.Round(10.5));

            Console.Read();

        }
    
    }
}
        //OUTPUT:
        //12
        //10


