﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class DictionaryEx
    {
        public static void Main_2(string[] args)
        {

            Dictionary<int, string> d = new Dictionary<int, string>();
            d.Add(1, "111");
            d.Add(2, "Javid");
            d.Add(3, "Solapur");
            d.Add(4, "9766399981");

            foreach (KeyValuePair<int, string> D in d)
            {
                Console.WriteLine("Key: {0}, Value: {1}", D.Key, D.Value);
            }

            Console.WriteLine("Enter key to be deleted");
            int a = Convert.ToInt32(Console.ReadLine());
            if (!d.ContainsKey(a))
            {
                Console.WriteLine("Key does not exist in Collection..!");

            }
            else
            {
                d.Remove(a);
                Console.WriteLine("Key Removed Successfully and new Collection is:");
            }


            foreach (KeyValuePair<int, string> D in d)
            {
                Console.WriteLine("Key: {0}, Value: {1}", D.Key, D.Value);
            }


            Console.Read();

        }
    }
}
        // OUTPUT:
        //Key: 1, Value: 111
        //Key: 2, Value: Javid
        //Key: 3, Value: Solapur
        //Key: 4, Value: 9766399981
        //Enter key to be deleted
        //3
        //Key Removed Successfully and new Collection is:
        //Key: 1, Value: 111
        //Key: 2, Value: Javid
        //Key: 4, Value: 9766399981