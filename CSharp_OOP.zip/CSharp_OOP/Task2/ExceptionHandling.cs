﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThirdPartyLibrary;

namespace Task2
{

    class ExceptionHandling
    {

        public static void Main_12(string[] args)
        {
            //Example for Exception handling using array for 5 students names
            string[] student = new string[5];
            string name;
            try
            {
                Console.WriteLine("Enter Student Names:");

                for (int i = 0; i <= 4; i++)
                {
                    name = Console.ReadLine();
                    student[i] = name;
                }

                Console.WriteLine("Array of students entered bye user: ");

                for (int i = 0; i <= 4; i++)
                {
                    Console.WriteLine(student[i]);
                   
                }

                //Console.WriteLine("Enter Student Names:");
                name = Console.ReadLine();
                student[6] = name;
                

            }

            catch (IndexOutOfRangeException e)
            {

                Console.WriteLine(e.Message);

            }

            catch (Exception)
            {

                Console.WriteLine("error 404:x - array size is full. exception is handled");


            }
            //For loop for printing array which stored the names of 5 studends afte catching exception
            //for (int i = 0; i <= 4; i++)
            //{
            //    Console.WriteLine(student[i]);

            //}

            Console.Read();
        }
    }
}


        /* OUTPUT:
            Enter Student Names:
            Javid
            Somnath
            Monika
            Anjali
            Sakshi
            Array of students entered bye user:
            Javid
            Somnath
            Monika
            Anjali
            Sakshi

            Akhil
            Index was outside the bounds of the array.
         */



